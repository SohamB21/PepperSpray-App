import React from 'react';
import {View, Text} from 'react-native';

const SettingsScreen = () => {
  return (
    <View>
      <Text style={{color: 'black'}}>Welcome to Settings!</Text>
    </View>
  );
};

export default SettingsScreen;
