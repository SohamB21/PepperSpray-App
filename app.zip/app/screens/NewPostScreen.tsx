import React from 'react';
import {View, Text} from 'react-native';

const NewPostScreen = () => {
  return (
    <View>
      <Text style={{color: 'black'}}>Welcome to NewPost!</Text>
    </View>
  );
};

export default NewPostScreen;
